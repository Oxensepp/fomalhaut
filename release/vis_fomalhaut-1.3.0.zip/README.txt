Fomalhaut for Winamp and WACUP
==============================

Retro music visualisations - the classics from before 2000, heavily inspired
by Cthugha: Cthugha 5.3 DOS, Cthugha98, Cthugha-L, Cthugha-4-Winamp, the Atari
Video Music C240 (1977), VSG+ DOS, the screens of 18 music trackers (Amiga,
DOS, Windows, C64, CPC), the Credits and a Mix of all of them.

Requirements: Winamp 5.x (32-bit) or WACUP (32-bit). The 64-bit WACUP does not
load third-party plug-ins yet.


Installation
------------

1. Close Winamp / WACUP.
2. Copy vis_fomalhaut.dll into the Plugins folder of Winamp / WACUP
   (for example C:\Program Files (x86)\Winamp\Plugins).
3. Start Winamp / WACUP, open Preferences > Plug-ins > Visualisation and
   select "Fomalhaut". Choose the mode under "Plug-in module", then Start
   (or press Ctrl+Shift+K).

Portable WACUP: third-party plug-ins must be allowed first under
Preferences > Advanced > Portable Mode (WACUP restarts).

To start the visualisation together with Winamp / WACUP, tick "Run the
plug-in(s) on start-up" in the Visualisation menu.


Use
---

- Click or Space: next effect. F1: all keys. Middle click or F11: fullscreen.
- Right-click: modes, presets, CRT filter, Atari Video Music controls and the
  settings. The settings are also under "Configure" in the Winamp preferences.
- Move the mouse to the top of the picture: the control bar slides in (mode,
  previous/next, lock, presets, CRT filter, fullscreen, settings; in the
  Cthugha modes also flame, wave, display, palette ...).
- Atari Video Music: move the mouse to the bottom of the picture and the front
  panel slides in.
- Keys that Fomalhaut does not use (Z, X, C, V, B, arrows ...) go to Winamp.
- Settings are stored in Plugins\vis_fomalhaut.ini in the Winamp settings
  folder.

Winamp passes only short pieces of the sound to a visualisation (576 values,
about 60 times a second). Fomalhaut joins them into a continuous stream; small
gaps are filled. In foobar2000 (foo_fomalhaut) all modes get the full sound.


Credits and license
-------------------

Inspired by Cthugha (c) 1993-1998 Kevin "Zaph" Burfitt, Torps Productions, and
Cthugha-L (c) 1995-1998 Harald Deischinger; Cthugha-4-Winamp (c) 1998 Krunoslav
Pisacic. Full credits: "About" in the settings, and THIRD-PARTY-NOTICES.txt.
Fomalhaut is free of charge and not affiliated with the Cthugha authors; the
unmodified package may be passed on, as long as no fee is charged for it.
See LICENSE.txt.

Fomalhaut for foobar2000 and news: https://github.com/Oxensepp/fomalhaut
